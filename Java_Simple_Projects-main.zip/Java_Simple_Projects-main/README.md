# Java_Simple_Projects
I want to share every little tiny things that I've learned.
